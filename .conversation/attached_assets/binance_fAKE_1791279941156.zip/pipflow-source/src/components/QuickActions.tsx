import { BarChart3, PiggyBank, Trophy, UserPlus, LayoutGrid } from "lucide-react";

const quickActions = [
  { icon: BarChart3, label: "Stocks" },
  { icon: PiggyBank, label: "Earn" },
  { icon: Trophy, label: "Football\nCup" },
  { icon: UserPlus, label: "Referral" },
  { icon: LayoutGrid, label: "More" },
];

export const QuickActions = () => {
  return (
    <div className="flex gap-2 overflow-x-auto pb-2 -mx-1 px-1">
      {quickActions.map((action) => (
        <button
          key={action.label}
          className="flex flex-col items-center gap-2 min-w-[64px] group"
        >
          <div className="bg-card border border-border rounded-full p-3 group-hover:bg-muted transition-colors">
            <action.icon className="h-5 w-5 text-foreground" />
          </div>
          <span className="text-[11px] text-center text-muted-foreground whitespace-pre-line leading-tight">
            {action.label}
          </span>
        </button>
      ))}
    </div>
  );
};
