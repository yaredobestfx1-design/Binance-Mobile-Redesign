import { TrendingUp, ArrowLeftRight, Briefcase, Wallet } from "lucide-react";
import { NavLink } from "@/components/NavLink";
import binanceLogo from "@/assets/binance-coin-logo.svg";

const navItems = [
  { icon: null, label: "Home", path: "/", customIcon: binanceLogo },
  { icon: TrendingUp, label: "Markets", path: "/" + "markets" },
  { icon: ArrowLeftRight, label: "Trade", path: "/trade" },
  { icon: Briefcase, label: "Futures", path: "/futures" },
  { icon: Wallet, label: "Assets", path: "/assets" },
];

export const BottomNav = () => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-background border-t border-border">
      <div className="flex items-center justify-around py-2 px-2 max-w-md mx-auto">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className="flex flex-col items-center gap-1 py-2 px-4 text-muted-foreground transition-colors"
            activeClassName="text-primary"
          >
            {item.customIcon ? (
              <img src={item.customIcon} alt={item.label} className="h-5 w-5" />
            ) : (
              item.icon && <item.icon className="h-5 w-5" />
            )}
            <span className="text-[11px] font-medium">{item.label}</span>
          </NavLink>
        ))}
      </div>
    </nav>
  );
};
