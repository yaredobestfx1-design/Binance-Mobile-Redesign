import { TopBar } from "@/components/TopBar";
import { BottomNav } from "@/components/BottomNav";
import { Button } from "@/components/ui/button";

const Trade = () => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <TopBar />
      
      <main className="pb-20 px-4 py-6 flex flex-col items-center justify-center min-h-[60vh]">
        <div className="text-center space-y-4">
          <div className="text-6xl mb-4">📊</div>
          <h1 className="text-2xl font-bold">Trade</h1>
          <p className="text-muted-foreground max-w-sm">
            Trading interface coming soon. Start trading your favorite cryptocurrencies.
          </p>
          <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
            Get Started
          </Button>
        </div>
      </main>

      <BottomNav />
    </div>
  );
};

export default Trade;
